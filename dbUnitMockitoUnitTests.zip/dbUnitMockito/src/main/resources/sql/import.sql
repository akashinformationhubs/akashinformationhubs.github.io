insert into User(id,name,sex, phone) values (1,'User1','M','123123123');

insert into User(id,name,sex, phone) values (2,'User2','F','123123123');

insert into User(id,name,sex, phone) values (3,'User3','F','123123123');

insert into User(id,name,sex, phone) values (4,'User4','M','123123123');

insert into User(id,name,sex, phone) values (5,'User5','F','123123123');
