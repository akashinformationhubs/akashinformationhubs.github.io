
package com.user.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.user.dao.UserDAO;
import com.user.model.User;

@Component
public class UserService {

	@Autowired
	private UserDAO userDAO;

	public UserDAO getClientDAO() {
		return userDAO;
	}

	public void setClientDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}

	public User find(long id) {
		return userDAO.find(id);
	}

	public void create(User user) {
		userDAO.create(user);
	}

	public void update(User user) {
		userDAO.update(user);
	}

	public void delete(User user) {
		userDAO.delete(user);
	}

}
