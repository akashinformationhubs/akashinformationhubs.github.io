
package com.user.core;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.user.model.User;
import com.user.service.UserService;

public class App {

	public static void main(String[] args) {

		// Test if all the deps are configured properly
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfiguration.class);

		UserService service = context.getBean(UserService.class);

		System.out.println(service.find(1).getName());
		System.out.println(service.find(3).getName());
		System.out.println(service.find(5).getName());

		User user = new User();

		user.setId(6);
		user.setName("UserXYZ");
		user.setPhone(123123123);
		user.setSex("F");
		service.create(user);
		System.out.println(service.find(6).getName());
		((AbstractApplicationContext) context).close();
		System.exit(0);
	}

}
