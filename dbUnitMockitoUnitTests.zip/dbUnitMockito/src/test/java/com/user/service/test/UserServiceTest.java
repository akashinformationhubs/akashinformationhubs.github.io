
package com.user.service.test;

import static org.junit.Assert.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;

import com.user.dao.UserDAO;
import com.user.model.User;
import com.user.service.UserService;

public class UserServiceTest {

	private static UserDAO userDAO;

	private static UserService userService;

	@BeforeClass
	public static void beforeClass() {
		userService = new UserService();
		userDAO = Mockito.mock(UserDAO.class);
		userService.setClientDAO(userDAO);

		User user = new User();
		user.setId(0);
		user.setName("Mocked User Object!");
		user.setPhone(11111111);
		user.setSex("M");

		Mockito.when(userDAO.find(Mockito.anyLong())).thenReturn(user);
		Mockito.doThrow(new RuntimeException("error on user object!")).when(userDAO).delete((User) Mockito.any());
		Mockito.doNothing().when(userDAO).create((User) Mockito.any());

		Mockito.doAnswer(new Answer<Object>() {

			public Object answer(InvocationOnMock invocation) {
				Object[] args = invocation.getArguments();
				User user = (User) args[0];
				user.setName("Mocked User has changed!");
				return user;
			}
		}).when(userDAO).update((User) Mockito.any());
	}

	@Test
	public void testFind() {
		User user = userService.find(10);
		Mockito.verify(userDAO).find(10);
		assertEquals(user.getName(), "Mocked User Object!");
	}

	@Test
	public void testInsert() {
		User user = new User();
		user.setId(3);
		user.setName("Michael Dell");
		user.setPhone(44657688);
		user.setSex("M");
		userService.create(user);
		Mockito.verify(userDAO).create(user);
	}

	@Test
	public void testUpdate() {
		User user = userService.find(20);
		user.setPhone(12345678);
		userService.update(user);
		Mockito.verify(userDAO).update(user);
		assertEquals(user.getName(), "Mocked User has changed!");
	}

	@Test(expected = RuntimeException.class)
	public void testRemove() {
		User user = userService.find(2);
		userService.delete(user);
	}

}
